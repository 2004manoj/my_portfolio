<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from soliman.netlify.app/index_static by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 Feb 2025 05:48:15 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- META DATA -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- TITLE OF SITE -->
    <title>Manoj Kumar-Portfolio</title>

    <!-- favicon -->
    <link id="favicon" rel="icon" type="image/png" href="assets/images/favicon.jpg">

    <!-- Google Fonts-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500%7CMontserrat:300,400,500,600,700,800,900">

    <!-- Bootstrap css -->
    <link rel="stylesheet" href="assets/css/bootstrap.css">

    <!-- animate.css -->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!-- magnific-popup.css -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- owl carousel css -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.min.css">

    <!-- font-awesome.min.css -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!-- Main style css -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Responsive css -->
    <link rel="stylesheet" href="assets/css/responsive.css">

    <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>

<body data-spy="scroll" data-target=".navbar" data-offset="70">


    <!--Start Preloader-->
    <div class="page-loader"></div>
    <div class="loader startLoad"></div>
    <div id="loader" class="pageload-overlay" data-opening="m -10,-10 0,80 100,0 0,-80 z m 50,-30.5 0,70.5 0,70 0,-70 z">
        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 80 60" preserveAspectRatio="none">
            <path d="m -10,-10 0,80 100,0 0,-80 z M 40,-40.5 120,30 40,100 -40,30 z" />
        </svg>
    </div>
    <!--End Preloader-->


    <!--Start Scroll Top-->
    <div class="top">
        <a href="#home" class="smooth_scroll"><i class="fa fa-angle-up fa-2x"></i></a>
    </div>
    <!--End Scroll Top-->


    <!--Start Home Section-->
    <section class="home" id="home">
        <div class="full_height" data-parallax="scroll" data-image-src="assets/images/me-1.jpg">

            <!-- nav -->
            <nav class="navbar navbar-default navbar-fixed-top">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>

                        <!-- LOGO -->
                        <a class="navbar-brand" href="#">MANOJ KUMAR</a>

                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="#home" class="smooth_scroll">Home</a>
                            </li>
                            <li>
                                <a href="#about" class="smooth_scroll">About</a>
                            </li>
                            <li>
                                <a href="#services" class="smooth_scroll">Services</a>
                            </li>
                            <li>
                                <a href="#experience" class="smooth_scroll">Experience</a>
                            </li>
                            <li>
                                <a href="#blog" class="smooth_scroll">Blog</a>
                            </li>
                            <li>
                                <a href="#testimonials" class="smooth_scroll">Testimonials</a>
                            </li>
                            <li>
                                <a href="#contact" class="smooth_scroll">Contact</a>
                            </li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!--.container-->
            </nav>
            <div class="display-table">
                <div class="display-table-cell">
                    <h1>Manoj kumar</h1>
                    <h3>
                        <span>web designer</span>
                        <span>full stack developer</span>
                        <span>freelancer</span>
                    </h3>
                    <ul class="text-center list-unstyled social">
                        <li>
                            <a href="https://www.facebook.com/profile.php?id=100084211855966">
                                <i class="fa fa-facebook fa-2x"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://x.com/Mano_1309">
                                <i class="fa fa-twitter fa-2x"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://wa.me/917550317855" target="_blank">
                                <i class="fa fa-whatsapp fa-2x"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/in/manoj-kumar-45278a262/">
                                <i class="fa fa-linkedin fa-2x"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/_m.a_n.o?igsh=aXdocXR2ajJ0YXc=">
                                <i class="fa fa-instagram fa-2x"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="scroll_down">
                <span></span>
            </div>
        </div><!--.full_height-->
    </section>
    <!--End Home Section-->

    <!--Start About Section-->
    <section class="about padding-top-90 padding-bottom-90" id="about">
        <div class="container">
            <div class="row">
                <div class="col-md-5 about-img">
                    <div class="my__img animated animated_scroll fadeInUp" style="animation-delay: 0.3s">
                        <img src="assets/images/manoj.jpg" alt="">
                    </div>
                </div>
                <div class="col-md-7 padding-left-35">
                    <h3 class="animated animated_scroll fadeInUp" style="animation-delay: 0.3s">Hi There! I am Manoj Kumar</h3>
                    <p class="animated animated_scroll fadeInUp" style="animation-delay: 0.3s">I am Manoj Kumar , a 20-year-old aspiring Full-Stack Developer passionate about building dynamic and efficient web applications. Currently pursuing my B.Tech in Artificial Intelligence & Data Science, I have a strong foundation in HTML, CSS, JavaScript, and am expanding my skills in MERN stack (MongoDB, Express.js, React.js, Node.js) to become a proficient developer.</p>
                    <p class="animated animated_scroll fadeInUp" style="animation-delay: 0.3s">I have completed a web development internship at Aurotech,Freindzion Technologies, where I gained hands-on experience in front-end technologies. Now, I am diving deeper into Laravel for back-end development and improving my problem-solving skills. My goal is to become a skilled full-stack developer by dedicating time to consistent learning and practice.</p>


                    <div class="about_btns animated animated_scroll fadeInUp" style="animation-delay: 0.3s">
                        <a href="cv.pdf" download="Manoj_Kumar_cv.pdf">Download CV</a>
                        <a href="#contact" class="smooth_scroll">Contact Me</a>
                    </div>
                </div><!--.col-sm-7-->
            </div><!--.row-->
        </div><!--.container-->
    </section>
    <!--End About Section-->


    <!--Start Services Section-->
    <section class="services padding-top-90 padding-bottom-90 primary_bg" id="services">
        <div class="container">
            <div class="sec_title">
                <h2>services</h2>
            </div>

            <div class="row">

                <!--Service 1-->
                <div class="col-md-3 col-sm-6 item animated animated_scroll fadeInUp" style="animation-delay: 0.3s">
                    <div class="content">
                        <div class="icon">
                            <i class="fa fa-desktop"></i>
                        </div>
                        <h3>Front-End Development</h3>
                        <p>Responsive UI design using HTML, CSS, JavaScript, Bootstarp and Mobile-friendly web pages.</p>
                    </div>
                </div>

                <!--Service 2-->
                <div class="col-md-3 col-sm-6 item animated animated_scroll fadeInUp" style="animation-delay: 0.6s">
                    <div class="content">
                        <div class="icon">
                            <i class="fa fa-database"></i>
                        </div>
                        <h3>Back-End Development</h3>
                        <p>End-to-end web solutions using(Mysql,Laravel,PHP) and Complete web application development</p>
                    </div>
                </div>

                <!--Service 3-->
                <div class="col-md-3 col-sm-6 item animated animated_scroll fadeInUp" style="animation-delay: 0.9s">
                    <div class="content">
                        <div class="icon">
                            <i class="fa fa-globe"></i>
                        </div>
                        <h3>Web Hosting</h3>
                        <p>I provide secure and reliable web hosting solutions to help businesses and individuals bring their websites online seamlessly.</p>
                    </div>
                </div>

                <!--Service 4-->
                <div class="col-md-3 col-sm-6 item animated animated_scroll fadeInUp" style="animation-delay: 1.2s">
                    <div class="content">
                        <div class="icon">
                            <i class="fa fa-cogs"></i>
                        </div>
                        <h3>Web Maintainance</h3>
                        <p>I provide regular website maintenance to ensure(Bug Fixes & Issue Resolution) your site stays secure, fast, and up to date.
                    </div>
                </div>

            </div><!--.row-->
        </div><!--.container-->
    </section>
    <!--End Services Section-->


    <!-- Container for the Experience Section -->
    <section class="experience padding-top-90 padding-bottom-90" id="experience">
        <div class="container my-5">
            <h2 class="text-center mb-4">Experience & Internships</h2>

            <div class="row g-4">
                <!-- Company 1 -->
                <div class="col-md-6">
                    <div class="card shadow-sm h-100">
                        <img
                            src="https://static.vecteezy.com/system/resources/previews/011/637/858/original/internship-flat-style-illustration-design-free-vector.jpg"
                            class="card-img-top"
                            alt="Company 1" />
                        <div class="card-body">
                            <small class="text-muted">MAY 2024 - JUNE 2024</small>
                            <h5 class="card-title mt-2">Web Development Intern</h5>
                            <p class="card-text">
                                Gained hands-on experience in front-end development, focusing on
                                responsive design, UI/UX improvements, and JavaScript best practices.
                            </p>
                        </div>
                        <div class="card-footer bg-white border-0">
                            <a
                                href="{{route('internpage1')}}"
                                class="btn btn-primary btn-sm">Read More</a>
                        </div>
                    </div>
                </div>

                <!-- Company 2 -->
                <div class="col-md-6">
                    <div class="card shadow-sm h-100">
                        <img
                            src="https://i.pinimg.com/736x/40/92/8d/40928d9ea4427e7036e270e4b0c2f341.jpg"
                            class="card-img-top"
                            alt="Company 2" />
                        <div class="card-body">
                            <small class="text-muted">FEB 2025 - MAR 2025</small>
                            <h5 class="card-title mt-2">Full Stack Intern</h5>
                            <p class="card-text">
                                Gained hands-on experience in Full Stack development, focusing on
                                database management, and RESTful API
                                integration using the Laravel framework.
                            </p>
                        </div>
                        <div class="card-footer bg-white border-0">
                            <a
                                href="{{route('internpage2')}}"
                                class="btn btn-primary btn-sm">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Start Blog Section-->
    <section class="blog padding-top-90 padding-bottom-90 primary_bg" id="blog">
        <div class="container">
            <div class="sec_title">
                <h2>Our Blog</h2>
            </div>
            <div class="row">

                <div class="col-xs-offset-1 col-xs-10 col-sm-offset-2 col-sm-8 col-md-offset-0 col-md-4 item animated animated_scroll fadeInUp" style="animation-delay: 0.3s">
                    <div class="blog__img">
                        <img src="https://blog.eduonix.com/wp-content/uploads/2018/09/Full-Stack-Developer.jpg" alt="">
                    </div>
                    <div class="content">
                        <span class="bold">April 15,2024</span>
                        <a href="{{route('blogpage1')}}">
                            <h3>My Journey into Full-Stack Development</h3>
                        </a>
                        <p>Learning full-stack development felt overwhelming at first, but step by step, I moved from basic HTML and CSS to building real projects. In this blog, I’ll share my journey, the challenges I faced, and how I kept improving my skills on Full Stack Development.</p>
                        <a
                            href="{{route('blogpage1')}}"
                            class="btn btn-primary btn-sm">Read More</a>
                    </div>
                </div>

                <div class="col-xs-offset-1 col-xs-10 col-sm-offset-2 col-sm-8 col-md-offset-0 col-md-4 item animated animated_scroll fadeInUp" style="animation-delay: 0.6s">
                    <div class="blog__img">
                        <img src="https://codup.co/wp-content/uploads/2021/08/full-stack-development.png" alt="">
                    </div>
                    <div class="content">
                        <span class="bold">September 19, 2024</span>
                        <a href="{{route('blogpage2')}}">
                            <h3>Challenges I Faced as a Self-Taught Developer</h3>
                        </a>
                        <p>Being a self-taught developer comes with struggles—debugging issues, staying consistent,finding the right resources, and Gaining the right knowledge .
                            I’ve faced all of these but found ways to push through. In this blog, I’ll share my biggest challenges faced to manage my Other studies and how I overcame them .</p>
                        <a
                            href="{{route('blogpage2')}}"
                            class="btn btn-primary btn-sm">Read More</a>
                    </div>
                </div>

                <div class="col-xs-offset-1 col-xs-10 col-sm-offset-2 col-sm-8 col-md-offset-0 col-md-4 item animated animated_scroll fadeInUp" style="animation-delay: 0.9s">
                    <div class="blog__img">
                        <img src="https://visualstorageintelligence.com/wp-content/uploads/2020/03/Managing-Conflict-Graphic.png" alt="">
                    </div>
                    <div class="content">
                        <span class="bold">October 25, 2024</span>
                        <a href="{{route('blogpage3')}}">
                            <h3>How I Balance College, Internships, and Learning</h3>
                        </a>
                        <p>Juggling college, internships, and self-learning is tough, but with the right strategy, it’s possible. I’ve learned how to manage my time effectively while staying consistent in web development. Here’s how I do it.</p>
                        <a
                            href="{{route('blogpage3')}}"
                            class="btn btn-primary btn-sm">Read More</a>
                    </div>
                </div>

            </div><!--.row-->
        </div><!--.container-->
    </section>
    <!--End Blog Section-->


    <!--Start Testimonials Section-->
    <section class="testimonials" id="testimonials">
        <div class="container">
            <div class="sec_title">
                <h2>Reviews</h2>
            </div>
            <div class="owl-carousel animated animated_scroll fadeInUp" style="animation-delay: 0.4s" id="testimonial-carousel">

                <!--testimonial 1-->
                <div class="testimonial">
                    <div class="content">
                        <img src="http://pluspng.com/img-png/png-user-icon-circled-user-icon-2240.png" alt="">
                        <p>
                            The blog provided clear and practical tips on balancing college and internships. I found it very relatable and useful!
                        </p>
                        <h6 class="name-job">
                            <span class="name">SIVA</span>

                        </h6>
                    </div>
                </div>

                <!--testimonial 2-->
                <div class="testimonial">
                    <div class="content">
                        <img src="http://pluspng.com/img-png/png-user-icon-circled-user-icon-2240.png" alt="">
                        <p>
                            I used their services for web development guidance, and they exceeded my expectations! The structured approach helped me improve my skills effectively.
                        </p>
                        <h6 class="name-job">
                            <span class="name">CHOWTHRI</span>

                        </h6>
                    </div>

                </div>

                <!--testimonial 3-->
                <div class="testimonial">
                    <div class="content">
                        <img src="http://pluspng.com/img-png/png-user-icon-circled-user-icon-2240.png" alt="">
                        <p>
                            Great insights on self-learning and time management. Also, their service for career guidance in full-stack development is highly recommended!
                        </p>
                        <h6 class="name-job">
                            <span class="name">THARUN</span>

                        </h6>
                    </div>
                </div>

            </div><!--.owl-carousel-->
        </div><!--.container-->
    </section>
    <!--End Testimonials Section-->


    <!--Start Contact Section-->
    <section class="contact padding-top-90 padding-bottom-90 primary_bg" id="contact">
        <div class="container">
            <div class="sec_title">
                <h2>Contact</h2>
            </div>

            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="row text-center info animated animated_scroll fadeInUp" style="animation-delay: 0.3s">

                        <div class="col-md-4">
                            <div class="content">
                                <span class="fa fa-phone"></span>
                                <div>
                                    <h4>Call Me</h4>
                                    <a href="tel:+917550317855">
                                        <p>+91 7550317855</p>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="content">
                                <span class="fa fa-envelope"></span>
                                <div>
                                    <h4>Mail Me</h4>
                                    <p><a href="mailto:manojkumarsasi18@gmail.com">click here</a></p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="content">
                                <span class="fa fa-map-marker"></span>
                                <div>
                                    <h4>Find Me</h4>
                                    <p>Hosur,Tamil Nadu</p>
                                </div>
                            </div>
                        </div>

                    </div><!--.row-->

                    <div class="contact_form animated animated_scroll fadeInUp" style="animation-delay: 0.4s">
                        @if(session('message'))
                        <div class="alert alert-warning">
                            {{session('message')}}

                        </div>
                        @endif
                        <form id="contactForm" action="{{ route('bookingpage') }}" method="POST">
                            @csrf
                            <input placeholder="Name" name="name" type="text" class="form-control">
                            <input placeholder="E-mail" name="email" type="email" class="form-control">
                            <textarea placeholder="Message" name="message" class="form-control"></textarea>
                            <button class="submit btn" type="button" onclick="submitForm(this)">Send Message</button> <!-- Change type to "button" -->
                            <div class="msg_success" style="display:none;">
                                <p>Your message has been sent. Thank you!</p>
                            </div>
                            <div class="msg_error" style="display:none;">
                                <p>Sorry, your message cannot be sent.</p>
                            </div>

                        </form>


                    </div>
                </div><!--.col-md-10-->
            </div><!--.row-->
        </div><!--.container-->
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.querySelector(".submit.btn").addEventListener("click", function(event) {
                    event.preventDefault(); // Prevent default form submission

                    let btn = this; // Reference the button
                    if (btn.disabled) return; // Prevent multiple clicks

                    console.log("Button clicked!"); // Debugging: Check if the button is working

                    btn.disabled = true; // Disable button after first click

                    btn.form.submit(); // Submit the form
                });
            });
        </script>
    </section>
    <!--End Contact Section-->

    <!--Start Footer-->
    <footer class="padding-top-90 padding-bottom-90">
        <div class="container text-center animated animated_scroll fadeInUp" style="animation-delay: 0.3s">
            <h3>Manoj</h3>

            <div class="social-links">
                <!--Social links-->
                <a href="https://www.facebook.com/profile.php?id=100084211855966" target="_blank">
                    <i class="fa fa-facebook"></i>
                </a>
                <a href="https://x.com/Mano_1309" target="_blank">
                    <i class="fa fa-twitter"></i>
                </a>
                <a href="https://wa.me/917550317855" target="_blank">
                    <i class="fa fa-whatsapp"></i>
                </a>
                <a href="https://www.linkedin.com/in/manoj-kumar-45278a262/" target="_blank">
                    <i class="fa fa-linkedin"></i>
                </a>
            </div>
            <p>&copy; 2025 Manoj | All rights reserved.</p>
            <script>
    document.getElementById("year").textContent = new Date().getFullYear();
</script>
        </div><!--.container-->
    </footer>
    <!--End Footer-->


    <!--jquery.min.js-->
    <script src="assets/js/jquery.min.js"></script>

    <!--parallax.min.js-->
    <script src="assets/js/parallax.min.js"></script>

    <!--snap.svg-min.js-->
    <script src="assets/js/snap.svg-min.js"></script>

    <!--classie.js-->
    <script src="assets/js/classie.js"></script>

    <!--svgLoader.js-->
    <script src="assets/js/svgLoader.js"></script>

    <!--animate-skills.js-->
    <script src="assets/js/animate-skills.js"></script>

    <!--jquery.fittext.js-->
    <script src="assets/js/jquery.fittext.js"></script>

    <!--bootstrap.min.js-->
    <script src="assets/js/bootstrap.min.js"></script>

    <!--jquery.magnific-popup.min.js-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--isotope.pkgd.min.js-->
    <script src="assets/js/isotope.pkgd.min.js"></script>

    <!--owl.carousel.min.js-->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Main script js -->
    <script src="assets/js/custom.js"></script>


</body>

<!-- Mirrored from soliman.netlify.app/index_static by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 Feb 2025 05:48:37 GMT -->

</html>