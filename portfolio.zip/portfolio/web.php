<?php


use App\Http\Controllers\InternshipController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::get('/manoj-profile',[InternshipController::class,'home'])->name('back');
Route::get('intern-page',[InternshipController::class,'view'])->name('internpage1');
Route::get('intern-page2',[InternshipController::class,'index'])->name('internpage2');
Route::get('blog-page1',[InternshipController::class,'blog1'])->name('blogpage1');
Route::get('blog-page2',[InternshipController::class,'blog2'])->name('blogpage2');
Route::get('blog-page3',[InternshipController::class,'blog3'])->name('blogpage3');
Route::post('/manoj-profile',[InternshipController::class,'message'])->name('bookingpage');

Route::get('records',[InternshipController::class,'records']);



