<?php

namespace App\Http\Controllers;

use App\Models\client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Jobs\SendEmailJob;

class InternshipController extends Controller
{
    public function home(){
        return view('layouts.index');
    }
    public function view(){
        return view('layouts.index2');
       }
       public function index(){
        return view('layouts.index3');
       }
       public function blog1(){
        return view('layouts.blog1');
       }
       public function blog2(){
        return view('layouts.blog2');
       }
       public function blog3(){
        return view('layouts.blog3');
       }

      public function message(Request $request) {
    // Validate the form input
    //dd($request->all());
  
    // Save the data to the database
    $client = new client();
    $client->name = $request->name;
    $client->email = $request->email;
    $client->message = $request->message;
    $client->save();

    // Send Email
    Mail::raw("New Contact Form Submission\n\nName: {$client->name}\nEmail: {$client->email}\nMessage: {$client->message}", function($message) use ($request) {
        $message->to('manojkumarsasi18@gmail.com')->subject('New Contact Form Submission')->from($request->email);
    });
    
    $data = ['name' => $client->name, 'email' => $client->email, 'message' => $client->message];
    dispatch(new SendEmailJob($data))->onQueue('emails');
   

    // Redirect back with a success message
    return redirect()->back()->with('success', 'Message sent successfully!');
}

//records from database
public function records(){
    
 $records=client::all();

 

return view('layouts.records',compact('records'));
//return $records=DB::table('clients')->get();
}

}
