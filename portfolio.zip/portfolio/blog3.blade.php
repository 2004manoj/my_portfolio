
<!DOCTYPE html>
<html lang="zxx">
    
<!-- Mirrored from soliman.netlify.app/index_static by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 Feb 2025 05:48:15 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <!-- META DATA -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- TITLE OF SITE -->
        <title>Manoj Kumar-Portfolio</title>

        <!-- favicon -->
        <link id="favicon" rel="icon" type="image/png"  href="assets/images/favicon.jpg">

        <!-- Google Fonts-->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500%7CMontserrat:300,400,500,600,700,800,900">

        <!-- Bootstrap css -->
        <link rel="stylesheet" href="assets/css/bootstrap.css">

        <!-- animate.css -->
        <link rel="stylesheet" href="assets/css/animate.css">

        <!-- magnific-popup.css -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- owl carousel css -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.min.css">

        <!-- font-awesome.min.css -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Main style css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- Responsive css -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>
    <body data-spy="scroll" data-target=".navbar" data-offset="70">


        <!--Start Preloader-->
        <div class="page-loader"></div>
        <div class="loader startLoad"></div>
        <div id="loader" class="pageload-overlay" data-opening="m -10,-10 0,80 100,0 0,-80 z m 50,-30.5 0,70.5 0,70 0,-70 z">
            <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 80 60" preserveAspectRatio="none" >
                <path d="m -10,-10 0,80 100,0 0,-80 z M 40,-40.5 120,30 40,100 -40,30 z"/>
            </svg>
        </div>
        <!--End Preloader-->


        <!--Start Scroll Top-->
        <div class="top">
            <a href="#home" class="smooth_scroll"><i class="fa fa-angle-up fa-2x"></i></a>
        </div>
        <!--End Scroll Top-->


        <!--Start Home Section-->
        <section class="home" id="home">
            <div class="full_height" data-parallax="scroll" data-image-src="assets/images/me-1.jpg">
                
                <!-- nav -->
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                            <!-- LOGO -->
                            <a class="navbar-brand" href="#">MANOJ KUMAR</a>

                        </div>
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-right">
                                <li>
                                    <a href="{{route('back')}}#home" >Home</a>
                                </li>
                                <li>
                                    <a href=" {{route('back')}}#about" >About</a>
                                </li>
                                <li>
                                    <a href="{{route('back')}}#services" >Services</a>
                                </li>
                                <li>
                                    <a href="{{route('back')}}#experience" >Experience</a>
                                </li>
                                <li>
                                    <a href="{{route('back')}}#blog" >Blog</a>
                                </li>
                                <li>
                                    <a href="{{route('back')}}#testimonials" >Testimonials</a>
                                </li>
                                <li>
                                    <a href="{{route('back')}}#contact" >Contact</a>
                                </li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div><!--.container-->
                </nav>
                <div class="display-table">
                    <div class="display-table-cell">
                        <h1>Manoj kumar</h1>
                        <h3>
                            <span>web designer</span>
                            <span>full stack developer</span>
                            <span>freelancer</span>
                        </h3>
                        <ul class="text-center list-unstyled social">
                            <li>
                                <a href="https://www.facebook.com/profile.php?id=100084211855966">
                                    <i class="fa fa-facebook fa-2x"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://x.com/Mano_1309">
                                    <i class="fa fa-twitter fa-2x"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://wa.me/917550317855" target="_blank">
                                    <i class="fa fa-whatsapp fa-2x"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/in/manoj-kumar-45278a262/">
                                <i class="fa fa-linkedin fa-2x"></i>                            
                                </a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/_m.a_n.o?igsh=aXdocXR2ajJ0YXc=">
                                    <i class="fa fa-instagram fa-2x"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="scroll_down"> 
                    <span></span> 
                </div>
            </div><!--.full_height-->
        </section>
        <!--End Home Section-->
        
        <div style="background-color: white;">
        
        <div class="container mt-5">
        <div class="card shadow-lg p-4">
            <h1 class="text-center text-primary">How I Balance College, Internships, And Learning</h1>
            <p class="text-muted text-center">October 25, 2024</p>
            <img src="https://visualstorageintelligence.com/wp-content/uploads/2020/03/Managing-Conflict-Graphic.png" alt="Balancing College and Learning" class="img-fluid rounded mx-auto d-block mb-4" style="max-width: 75%;">
            
            <p>Juggling college, internships, and self-learning is tough, but with the right strategy, it’s possible. I’ve learned how to manage my time effectively while staying consistent in web development.</p>
            
            <h3 class="text-success"><u>Time Management</u></h3>
            <p>Balancing multiple responsibilities required creating a structured daily schedule. I prioritized tasks and allocated fixed hours for studies, projects, and self-learning.</p>
            
            <h3 class="text-success"><u>Internship Experience</u></h3>
            <p>Working as an intern gave me real-world exposure. I applied my knowledge from self-learning and improved my problem-solving skills.</p>
            
            <h3 class="text-success"><u>Avoiding Burnout</u></h3>
            <p>Taking short breaks and maintaining a balance between work and rest helped me stay productive without feeling overwhelmed.</p>
            
            <h3 class="text-success"><u>Key Takeaways</u></h3>
            <p>With proper planning and dedication, it is possible to manage college, internships, and learning simultaneously. Staying organized and motivated made the process smoother.</p>
        </div>
    </div>
    </div>

    
<!--Start Footer-->
<footer class="padding-top-90 padding-bottom-90">
            <div class="container text-center animated animated_scroll fadeInUp" style="animation-delay: 0.3s">
                <h3>Manoj</h3>

                <div class="social-links">
                    <!--Social links-->
                    <a href="https://www.facebook.com/profile.php?id=100084211855966" target="_blank">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a href="https://x.com/Mano_1309" target="_blank">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a href="https://wa.me/917550317855" target="_blank">
                        <i class="fa fa-whatsapp"></i>
                    </a>
                    <a href="https://www.linkedin.com/in/manoj-kumar-45278a262/" target="_blank">
                    <i class="fa fa-linkedin"></i>  
                    </a>
                </div>
                <p>&copy; 2025 Manoj | All rights reserved.</p>
            </div><!--.container-->  
        </footer>
        <!--End Footer-->


        <!--jquery.min.js-->
        <script src="assets/js/jquery.min.js"></script>

        <!--parallax.min.js-->
        <script src="assets/js/parallax.min.js"></script>

        <!--snap.svg-min.js-->
        <script src="assets/js/snap.svg-min.js"></script>

        <!--classie.js-->
        <script src="assets/js/classie.js"></script>

        <!--svgLoader.js-->
        <script src="assets/js/svgLoader.js"></script>
        
        <!--animate-skills.js-->
        <script src="assets/js/animate-skills.js"></script>

        <!--jquery.fittext.js-->
        <script src="assets/js/jquery.fittext.js"></script>

        <!--bootstrap.min.js-->
        <script src="assets/js/bootstrap.min.js"></script>

        <!--jquery.magnific-popup.min.js-->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>

        <!--isotope.pkgd.min.js-->
        <script src="assets/js/isotope.pkgd.min.js"></script>

        <!--owl.carousel.min.js-->
        <script src="assets/js/owl.carousel.min.js"></script>

        <!-- Main script js -->
        <script src="assets/js/custom.js"></script>

        
    </body>

<!-- Mirrored from soliman.netlify.app/index_static by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 Feb 2025 05:48:37 GMT -->
</html>
